/**
 * 🌐 NAVEGACIÓN PRINCIPAL
 * Cambia las rutas o etiquetas según tu estructura.
 */

export interface NavItem {
  label: string;
  href: string;
  external?: boolean;
}

export const mainNav: NavItem[] = [
  { label: "Inicio", href: "/" },
  { label: "Proyectos", href: "/proyectos" },
  { label: "Habilidades", href: "/#habilidades" },
  { label: "Contacto", href: "/#contacto" },
];
