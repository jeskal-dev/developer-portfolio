/**
 * 📝 CONFIGURACIÓN PRINCIPAL DEL SITIO
 * ──────────────────────────────────────────────────────────────
 * Cambia estos valores por tus datos reales.
 * Todos los elementos hardcodeados del sitio viven aquí o en
 * archivos dentro de `/src/data/`.
 */

export interface SiteConfig {
  name: string; // Nombre para meta tags y branding
  shortName: string; // Versión corta (para PWA / nav móvil)
  title: string; // Título default para SEO
  description: string; // Descripción default para SEO
  author: string; // Tu nombre completo
  role: string; // Tu rol profesional
  email: string; // Email principal (CTA primario)
  locale: string; // idioma ISO
  url: string; // URL de producción (sin slash final)
  cvUrl?: string; // URL pública del CV descargable (PDF)
  // Textos del hero
  hero: {
    greeting: string;
    name: string;
    tagline: string; // Frase corta bajo el nombre
    summary: string; // Párrafo descriptivo (2-3 líneas)
    primaryStack: string[]; // Stack principal (ej. ["TypeScript","Rust","Java"])
  };
}

export const siteConfig: SiteConfig = {
  name: "DevPortfolio",
  shortName: "Portfolio",
  title: "Tu Nombre — Fullstack Developer | TypeScript · Rust · Java",
  description:
    "Desarrollador Fullstack especializado en TypeScript, Rust/Tauri y Java/Spring Boot. Casos de estudio de aplicaciones web, desktop y backends empresariales.",
  author: "Tu Nombre",
  role: "Fullstack Developer",
  email: "hello@tudominio.com",
  locale: "es-ES",
  url: "https://your-portfolio.example.com",
  cvUrl: "/cv.pdf",
  hero: {
    greeting: "Hola, soy",
    name: "Tu Nombre",
    tagline: "Ingeniero Fullstack · Construyo software de alto rendimiento",
    summary:
      "Especialista en TypeScript, Rust/Tauri y Java/Spring Boot. Diseño aplicaciones web, desktop y backends empresariales con foco en rendimiento, seguridad y experiencia de desarrollo.",
    primaryStack: ["TypeScript", "Rust", "Java"],
  },
};
