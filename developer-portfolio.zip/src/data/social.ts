/**
 * 🔗 REDES Y CONTACTO PROFESIONAL
 * Cambia las URLs por tus perfiles reales.
 */

export interface SocialLink {
  label: string;
  href: string;
  icon: string; // identificador del ícono svg
  handle?: string; // texto mostrado (ej. @usuario)
}

export const socialLinks: SocialLink[] = [
  {
    label: "GitHub",
    href: "https://github.com/tu-usuario",
    icon: "github",
    handle: "github.com/tu-usuario",
  },
  {
    label: "LinkedIn",
    href: "https://linkedin.com/in/tu-usuario",
    icon: "linkedin",
    handle: "in/tu-usuario",
  },
  {
    label: "X (Twitter)",
    href: "https://x.com/tu_usuario",
    icon: "x",
    handle: "@tu_usuario",
  },
];
