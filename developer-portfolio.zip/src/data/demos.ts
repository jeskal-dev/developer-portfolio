export interface DemoAsset {
  title: string;
  description: string;
  platforms?: { label: string; href: string }[];
  href?: string;
  ctaLabel: string;
  type: "download" | "link";
}

export const demos: DemoAsset[] = [
  {
    title: "Widget de Productividad (Tauri)",
    description:
      "Mini-app de demostración construida con Rust + Tauri. Binarios nativos para Windows, macOS y Linux. Muestra el potencial de apps desktop ligeras con acceso al sistema.",
    platforms: [
      { label: "Windows", href: "#" },
      { label: "macOS", href: "#" },
      { label: "Linux", href: "#" },
    ],
    ctaLabel: "Descargar demo",
    type: "download",
  },
];
