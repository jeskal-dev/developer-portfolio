export interface Service {
  id: string; // slug del tipo de solución (debe coincidir con tipoSolucion de proyectos)
  title: string;
  description: string;
  icon: string; // identificador del svg
  stack: string[]; // stack representativo
}

export const services: Service[] = [
  {
    id: "Aplicacion Web",
    title: "Aplicaciones Web",
    description:
      "SPAs y SSR con React, Astro y NestJS. Arquitecturas escalables, UX cuidada y rendimiento de primer nivel.",
    icon: "web",
    stack: ["React", "Astro", "NestJS"],
  },
  {
    id: "Aplicacion Desktop",
    title: "Aplicaciones Desktop",
    description:
      "Apps nativas multiplataforma con Rust + Tauri. Binarios ligeros, arranque instantáneo y acceso al sistema.",
    icon: "desktop",
    stack: ["Rust", "Tauri", "Tokio"],
  },
  {
    id: "Backend Empresarial",
    title: "Backends Empresariales",
    description:
      "APIs robustas y seguras con Spring Boot + Hibernate. Listas para integrarse a sistemas corporativos críticos.",
    icon: "server",
    stack: ["Java", "Spring Boot", "PostgreSQL"],
  },
];
