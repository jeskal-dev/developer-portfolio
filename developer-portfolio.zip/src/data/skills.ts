export interface SkillEcosystem {
  id: string;
  name: string;
  level: "Experto" | "Avanzado" | "Intermedio";
  tech: { name: string; description: string }[];
  accent: "primary" | "success" | "warning"; // color de acento del ecosistema
}

export const skills: SkillEcosystem[] = [
  {
    id: "typescript",
    name: "TypeScript Ecosystem",
    level: "Experto",
    accent: "primary",
    tech: [
      {
        name: "React",
        description: "UIs componentales con hooks y server components.",
      },
      { name: "Astro", description: "SSG e islas para sitios ultrarrápidos." },
      {
        name: "NestJS",
        description: "Backends modulares con DI y decoradores.",
      },
      {
        name: "TanStack Start",
        description: "Meta-framework fullstack tipado.",
      },
      { name: "Express", description: "APIs REST minimalistas." },
    ],
  },
  {
    id: "rust",
    name: "Rust Ecosystem",
    level: "Avanzado",
    accent: "success",
    tech: [
      {
        name: "Tauri",
        description: "Apps desktop con backend Rust y frontend web.",
      },
      {
        name: "Tokio",
        description: "Runtime async para I/O de alta concurrencia.",
      },
      { name: "Serde", description: "Serialización/deserialización tipada." },
    ],
  },
  {
    id: "java",
    name: "Java Ecosystem",
    level: "Avanzado",
    accent: "warning",
    tech: [
      {
        name: "Spring Boot",
        description: "Microservicios y APIs empresariales.",
      },
      { name: "Maven", description: "Build y gestión de dependencias." },
      { name: "Hibernate", description: "ORM con JPA y HQL." },
    ],
  },
];
