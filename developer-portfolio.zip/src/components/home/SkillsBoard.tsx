import { useState } from "react";

export interface SkillTech {
  name: string;
  description: string;
}
export interface SkillEcosystem {
  id: string;
  name: string;
  level: "Experto" | "Avanzado" | "Intermedio";
  tech: SkillTech[];
  accent: "primary" | "success" | "warning";
}

interface Props {
  ecosystems: SkillEcosystem[];
}

const accentMap: Record<
  "primary" | "success" | "warning",
  { badge: string; border: string; glow: string }
> = {
  primary: {
    badge: "badge-primary",
    border: "var(--accent-primary)",
    glow: "oklch(0.7 0.15 220 / 0.25)",
  },
  success: {
    badge: "badge-success",
    border: "var(--accent-success)",
    glow: "oklch(0.7 0.18 145 / 0.25)",
  },
  warning: {
    badge: "badge-warning",
    border: "var(--accent-warning)",
    glow: "oklch(0.75 0.15 85 / 0.25)",
  },
};

export default function SkillsBoard({ ecosystems }: Props) {
  const [active, setActive] = useState<{ eco: string; tech: string } | null>(
    null,
  );

  const activeTech = active
    ? ecosystems
        .find((e) => e.id === active.eco)
        ?.tech.find((t) => t.name === active.tech)
    : null;

  return (
    <div className="skills-board">
      <div
        className="grid gap-4"
        style={{
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
        }}
      >
        {ecosystems.map((eco) => {
          const a = accentMap[eco.accent];
          return (
            <div
              key={eco.id}
              className="card-wrapper"
              style={{
                filter: `drop-shadow(0 4px 12px oklch(0 0 0 / 0.4))`,
                transition: "filter 0.25s ease",
              }}
            >
              <div
                className="card-inner geom-cut-md"
                style={{ padding: "var(--cut-size-md)" }}
              >
                <div
                  className="flex items-center justify-between mb-3"
                  style={{ gap: "0.5rem" }}
                >
                  <h3
                    style={{
                      fontSize: "1.05rem",
                      fontWeight: 700,
                      color: "var(--text-primary)",
                      margin: 0,
                    }}
                  >
                    {eco.name}
                  </h3>
                  <span className={`badge geom-cut-sm ${a.badge}`}>
                    {eco.level}
                  </span>
                </div>
                <ul
                  className="skill-tech-list"
                  style={{
                    listStyle: "none",
                    padding: 0,
                    margin: 0,
                    display: "flex",
                    flexDirection: "column",
                    gap: "0.4rem",
                  }}
                >
                  {eco.tech.map((t) => {
                    const isActive =
                      active?.eco === eco.id && active?.tech === t.name;
                    return (
                      <li key={t.name}>
                        <button
                          type="button"
                          onClick={() =>
                            setActive(
                              isActive ? null : { eco: eco.id, tech: t.name },
                            )
                          }
                          onMouseEnter={() =>
                            setActive({ eco: eco.id, tech: t.name })
                          }
                          className="skill-tech-btn"
                          style={{
                            width: "100%",
                            textAlign: "left",
                            background: isActive ? a.glow : "transparent",
                            color: isActive
                              ? a.border
                              : "var(--text-secondary)",
                            border: "1px solid",
                            borderColor: isActive
                              ? a.border
                              : "var(--border-default)",
                            borderRadius: "var(--radius-soft)",
                            padding: "8px 12px",
                            fontFamily: "'JetBrains Mono', monospace",
                            fontSize: "0.85rem",
                            cursor: "pointer",
                            transition:
                              "background 0.2s ease, color 0.2s ease, border-color 0.2s ease",
                          }}
                        >
                          <span style={{ fontWeight: 600 }}>{t.name}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
          );
        })}
      </div>

      {/* Panel de descripción de la tech activa */}
      <div className="card-wrapper mt-4" style={{ marginTop: "1rem" }}>
        <div
          className="card-inner geom-cut-md"
          style={{
            padding: "var(--cut-size-md)",
            minHeight: "72px",
            display: "flex",
            alignItems: "center",
          }}
        >
          {activeTech ? (
            <p
              style={{
                margin: 0,
                color: "var(--text-primary)",
                fontSize: "0.95rem",
              }}
            >
              <span
                style={{
                  fontFamily: "'JetBrains Mono', monospace",
                  color: "var(--accent-primary)",
                  fontWeight: 700,
                  marginRight: "0.5rem",
                }}
              >
                {activeTech.name}
              </span>
              <span style={{ color: "var(--text-secondary)" }}>
                {activeTech.description}
              </span>
            </p>
          ) : (
            <p
              style={{
                margin: 0,
                color: "var(--text-disabled)",
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: "0.85rem",
              }}
            >
              ▸ Pasa el cursor sobre una tecnología para ver su descripción.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
