import { defineCollection } from "astro:content";
import { z } from "astro/zod";
import { glob } from "astro/loaders";

/**
 * 📦 CONTENT COLLECTION: Proyectos
 * Schema de frontmatter para los casos de estudio en /src/content/proyectos/*.mdx
 */
const projects = defineCollection({
  loader: glob({
    base: "./src/content/projects",
    pattern: "**/*.{md,mdx}",
  }),
  schema: z.object({
    title: z.string(),
    code: z.string(),
    tipoSolucion: z.string(), // debe coincidir con services[].id
    stack: z.array(z.string()),
    destacado: z.boolean().default(false),
    fecha: z.coerce.date(),
    imagenPortada: z.string().optional(),
    problema: z.string(),
    solucion: z.string(),
    resultados: z.string(),
    // opcionales
    cliente: z.string().optional(),
    duracion: z.string().optional(),
    galeria: z.array(z.string()).optional(),
    // SEO override por proyecto
    seoDescription: z.string().optional(),
  }),
});

export const collections = { projects };
