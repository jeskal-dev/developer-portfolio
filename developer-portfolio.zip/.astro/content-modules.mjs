
export default new Map([
["src/content/projects/backend-fintech-spring.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fprojects%2Fbackend-fintech-spring.mdx&astroContentModuleFlag=true")],
["src/content/projects/dashboard-telemetria-iot.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fprojects%2Fdashboard-telemetria-iot.mdx&astroContentModuleFlag=true")],
["src/content/projects/ecommerce-b2b.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fprojects%2Fecommerce-b2b.mdx&astroContentModuleFlag=true")],
["src/content/projects/widget-productividad-tauri.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fprojects%2Fwidget-productividad-tauri.mdx&astroContentModuleFlag=true")]]);
		